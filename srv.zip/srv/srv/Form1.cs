﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Net;
using System.Net.Sockets;
using System.Threading;

namespace srv
{
	public partial class Form1 : Form
	{
		public Form1()
		{
			InitializeComponent();
			textBox2.Text = "127.0.0.1";
			textBox1.Text = "50000";
		}
		bool pokrenuti = false;
		TcpListener server = null;
		Thread thrServer;
		Byte[] bytes = new Byte[256];
        String data = null;
		NetworkStream stream;
        
        void serverListen()
        {
            server = new TcpListener(IPAddress.Parse(textBox2.Text),Int32.Parse(textBox1.Text));
            server.Start();
            while (pokrenuti)
            {
                try
                {
                    poruke.Invoke((MethodInvoker)(() => poruke.AppendText("\r\n Čekanje na vezu...")));
                    TcpClient client = server.AcceptTcpClient();
                    if (client.Connected==true)
                    {
                        poruke.Invoke((MethodInvoker)(() => poruke.AppendText("\r\n Klijent povezan na server!")));
                        
                    }

                    stream = client.GetStream();

                    int i;
                    while ((i = stream.Read(bytes, 0, bytes.Length)) != 0)
                    {
                        data = System.Text.Encoding.ASCII.GetString(bytes, 0, i);
                        poruke.Invoke((MethodInvoker)(() => poruke.AppendText("\r\n"+data)));
                        string znak = data.Substring(0,1);
                        string gumb=data.Substring(1, data.Length-1);

                        string empty = data;
                        if(empty!=" ")
                        {
                            poruke.Invoke((MethodInvoker)(() => poruke.AppendText("\r\nznak: " + znak)));
                            poruke.Invoke((MethodInvoker)(() => poruke.AppendText("\r\ngumb: " + gumb)));

                        }
                        

                        if (gumb == "button12")
                        {
                            button12.Invoke((MethodInvoker)(() => button12.Text = znak));
                        }
                        if (gumb == "button11")
                        {
                            button11.Invoke((MethodInvoker)(() => button11.Text = znak));
                        }
                        if (gumb == "button10")
                        {
                            button10.Invoke((MethodInvoker)(() => button10.Text = znak));
                        }
                        if (gumb == "button4")
                        {
                            button4.Invoke((MethodInvoker)(() => button4.Text = znak));
                        }
                        if (gumb == "button5")
                        {
                            button5.Invoke((MethodInvoker)(() => button5.Text = znak));
                        }
                        if (gumb == "button6")
                        {
                            button6.Invoke((MethodInvoker)(() => button6.Text = znak));
                        }
                        if (gumb == "button7")
                        {
                            button7.Invoke((MethodInvoker)(() => button7.Text = znak));
                        }
                        if (gumb == "button8")
                        {
                            button8.Invoke((MethodInvoker)(() => button8.Text = znak));
                        }
                        if (gumb == "button9")
                        {
                            button9.Invoke((MethodInvoker)(() => button9.Text = znak));
                        }
                        if (empty == " ")
                        {
                            button12.Invoke((MethodInvoker)((() => button12.Text = empty)));
                            button11.Invoke((MethodInvoker)((() => button11.Text = empty)));
                            button10.Invoke((MethodInvoker)((() => button10.Text = empty)));
                            button4.Invoke((MethodInvoker)((() => button4.Text = empty)));
                            button5.Invoke((MethodInvoker)((() => button5.Text = empty)));
                            button6.Invoke((MethodInvoker)((() => button6.Text = empty)));
                            button7.Invoke((MethodInvoker)((() => button7.Text = empty)));
                            button8.Invoke((MethodInvoker)((() => button8.Text = empty)));
                            button9.Invoke((MethodInvoker)((() => button9.Text = empty)));
                        }
                    }
                    client.Close();
                }
                catch
                {

                }
            }
        }
        private void button1_Click(object sender, EventArgs e)
		{
			if (!pokrenuti)
			{
				thrServer = new Thread(serverListen);
                thrServer.Start();
                pokrenuti = true;
			}
		}

        private void button2_Click(object sender, EventArgs e)
        {
            server.Stop();
        }

        private void Form1_FormClosed(object sender, FormClosedEventArgs e)
        {
            server.Stop();
        }
    }
}
